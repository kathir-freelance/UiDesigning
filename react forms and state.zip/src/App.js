import React from 'react';

import EmployeeList from './EmployeeList';
const aName='value from app';

class App extends React.Component  {
  
  state={
    employees:[
      {
            empName:'charlie',
            desig:'admin',
            age:34
      },
      {
        empName:'Anup',
        desig:'Manager',
        age:32
      },
      {
        empName:'Alex',
        desig:'developer',
        age:26
      }
    ]
  }
  deleteEmployee=(index)=>{
    const empStat=this.state.employees;

    this.setState(
      {
        employees: empStat.filter(
          (em,ind)=>{
            return ind!==index
          }),
      })
  }
  render(){
    
    return (
      <div>
        <FormComp/>
    <EmployeeList emp={this.state.employees} rem={this.deleteEmployee}/>
    </div>
    );
  }
}

class FormComp extends React.Component {
  constructor(props) {
    super(props);
    this.state = { username: '' };
    this.changeName=this.changeName.bind(this);
  }
  changeName(event){
    console.log('hi');
    this.setState({username:event.target.value})
  }
  render(){
  return(
    <form>
      <h1>{this.state.username}</h1>
      <input type='text'  onChange={this.changeName}/>
    </form>
  )
  }
}
export default App;
